import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from validate_report import validate

class TestValidator(unittest.TestCase):
    def test_empty(self):
        errors, _ = validate("")
        self.assertTrue(errors)

    def test_real_example(self):
        example = Path(__file__).resolve().parents[1] / "examples" / "N02_reading_report.md"
        errors, warnings = validate(example.read_text(encoding="utf-8"))
        self.assertEqual(errors, [], errors)
        self.assertEqual(warnings, [], warnings)


    def test_original_paper_comparing_review(self):
        example = (Path(__file__).resolve().parents[1] / 'examples' / 'E12_experiment_audit.md').read_text(encoding='utf-8')
        errors, warnings = validate(example)
        self.assertFalse(errors)
        self.assertFalse(warnings)

if __name__ == "__main__":
    unittest.main()
