#!/usr/bin/env python3
"""Conservative structural QA for generated paper-reading reports.

It cannot validate whether a quote, numerical claim or figure statement is true.
"""
from __future__ import annotations
import re
import sys
from pathlib import Path

REQUIRED = (
    "一段话读懂", "研究目的", "公式", "逐图", "仿真", "实验", "创新", "技术难关", "复现"
)


def validate(text: str) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    if not text.strip().startswith("# "):
        errors.append("Report must start with a Markdown H1 title")
    headings = re.findall(r"^#{1,6} +(.+)$", text, re.M)
    combined = " ".join(headings)
    for name in REQUIRED:
        if name not in combined:
            errors.append(f"Missing section heading containing: {name}")
    # All lines of tables are checked only for basic syntax.
    if not re.search(r"(?i)(fig(?:ure)?\.?\s*\d+)", text):
        errors.append("No explicit Figure number found")
    if not re.search(r"(?i)(eq(?:uation)?\.?\s*\(?\d+|公式[（(]?\d+)", text):
        warnings.append("No explicit equation number found")
    if not re.search(r"(?i)(p\.?\s*\d+|第\d+页|page\s+\d+)", text):
        errors.append("No page-level source location found")
    # Only enforce review-specific safeguards when the *current paper* is labeled a review.
    # A paper can cite/compare a review without itself being one.
    declared_review = bool(re.search(
        r"(?:研究类型|论文类型)[:：][^\n]{0,60}(?:综述|[Rr]eview|[Ss]urvey)", text
    ))
    if declared_review and not any(t in text for t in ["未报告原创", "无原创", "NOT_REPORTED", "没有原创"]):
        warnings.append("Review paper: explicitly disclose if original simulation/experiments are absent")
    if len(text) < 1500:
        warnings.append("Report is short: confirm all necessary evidence was inspected")
    return errors, warnings


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("Usage: python scripts/validate_report.py PATH_TO_REPORT.md")
        return 2
    path = Path(argv[1])
    if not path.is_file():
        print(f"ERROR: report not found: {path}")
        return 2
    errors, warnings = validate(path.read_text(encoding="utf-8"))
    print(f"Report: {path}")
    for msg in errors:
        print(f"ERROR: {msg}")
    for msg in warnings:
        print(f"WARNING: {msg}")
    print(f"Checked: {len(errors)} errors, {len(warnings)} warnings")
    return int(bool(errors))


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
