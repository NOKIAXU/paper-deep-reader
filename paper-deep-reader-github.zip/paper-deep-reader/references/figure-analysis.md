# Figure and table inspection protocol

For each captioned item record:

| Field | Required content |
|---|---|
| Figure/page | Exact author numbering and printed PDF page |
| Intended question | What hypothesis/claim is it designed to illustrate? |
| Visual anatomy | Circuit terminals, sign arrows, axes and units, traces/legend, settings |
| Observed evidence | What is visibly plotted; give numbers only if legible or printed in text |
| Physical explanation | Why the trend occurs, with equations and assumptions |
| Strength | Mechanism illustration / simulation / hardware measurement / conceptual comparison |
| Blind spots | Baseline fairness, sensor errors, missing uncertainty, other explanations |

Special cases:
- Block diagram: describe paths and signs, feedback/feedforward and controlled port; do not claim it is experimental evidence.
- Timeline/summary: describe the author's taxonomy, not a result from a trial.
- Bode: magnitude, phase, crossover, and operating frequency; distinguish open/closed loop.
- Nyquist: state characteristic ratio and open-loop pole count; encirclement without context is not a complete test.
- Tables: identify criteria and trade-offs; qualitative checks are author synthesis, not necessarily universal guarantees.

No copyrighted page images should be redistributed in the sample GitHub project without permission. Cite figure numbers; keep original PDFs outside the repository.
