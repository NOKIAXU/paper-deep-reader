# Simulation/experimental reproducibility audit

## Parameters
Capture source/BDC topology, direction of power flow, rated voltage/power, L/C/R (with units), switching/sampling frequencies, control gains/limits, simulation solver and step, initial conditions, disturbance components (frequency, amplitude, offset and timing), sensors and post-processing. For anything missing mark `NOT_REPORTED` and design independent sensitivity tests.

## Three-level plan
1. **Teaching model**: simple nonlinear state equations (e.g. RC-fed CPL) showing a mechanism; explicitly NOT a faithful paper reproduction.
2. **Average model**: switch-averaged buck/boost, current & voltage loops, negative incremental impedance under bandwidth limits, eigenvalue and impedance analysis.
3. **Switching/hardware**: gate PWM, delays, ripple, dead time, parasitics, sensor/ADC, protection; reproduce authors' comparison baselines if parameters are available.

## Essential checks
- Power balance, reference-ground, branch orientations, voltage sensor polarity.
- Baselines under same power/disturbance, correct measurement definitions and start-up transients excluded.
- Robustness over operating points, current constraints and feasible duty cycle.
- Never assign a simulation or hardware platform to a **review** simply because it displays schematics from cited papers.
