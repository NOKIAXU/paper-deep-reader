# Evidence-grounding rules | 证据规则

## Classification
- `AUTHOR_ORIGINAL`: equations, simulations or experiments carried out in the paper itself.
- `LITERATURE_REPORTED`: a statement about another work as described by the paper; identify citation number and distinguish from independently reading the reference.
- `EDUCATIONAL_DERIVATION`: a derivative calculation provided to help the reader, not a formula in the original text.
- `INFERENCE`: cautiously inferred research gap/hypothesis, never pass it off as author's claim.
- `NOT_REPORTED`: feature not present or not sufficiently specified; do not silently invent.

## Minimum citation
Mention PDF page (and printed page if different) + Figure/Table/Equation number or section. For externally sourced comparisons, include DOI/citation where verified. Paraphrase: do not copy long chunks verbatim.

## Metrics
- Voltage ripple: clearly label amplitude (zero-to-peak), peak-to-peak, RMS; never conflate.
- THD: state denominator/convention. DC-bus THD calculations may vary; if paper's method is not specified, say so.
- Impedances: ratio of perturbation voltage/current at the specific port and perturbation frequency, with sign convention.
- Eigenvalues and Nyquist: local linearization alone does not guarantee global large-signal stability. Encirclement rules require correct open-loop unstable pole count and loop definition.
- Model realism: a sinusoidal ideal current source is a prescribed disturbance, not a validated stochastic GPU load or a constant-power load.

## Handling gaps
Use the exact statements:
- `未报告：论文未提供原创仿真平台/实验平台/波形` for review-only pieces.
- `未完全给出：无法从论文独立恢复该参数` for partial specifications.
- `仅据本文对引用文献的描述，尚未独立核验原文` for secondary comparisons.

## Evidence ledger CSV fields
`claim,page,locator,classification,evidence_summary,confidence,notes`
